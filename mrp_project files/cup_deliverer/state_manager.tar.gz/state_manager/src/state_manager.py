# -*- coding: utf-8 -*-
"""
Created on Thu Jan 18 13:45:41 2018

The state manager controls the individual robots
and represents the state of whole system.

@author: Moritz Renftle
"""

import rospy
import actionlib

from mob_rob_msgs.msg import TransportCupAction, TransportCupGoal, AcceptCupAction, AcceptCupGoal,\
    NavigateCupAction, NavigateCupGoal, DeliverCupAction, DeliverCupGoal

"""
ActionServer responsible for the complete system consisting of
the three robots
  - cup acceptor
  - cup navigator
  - cup deliverer

Provides the "transport cup" action that starts and controls
all three robots until the cup was transported from the start table
to the goal table.
"""


class CupState:
    Idle = 0
    Accepting = 1
    Navigating = 2



class ActionExecutor:
    def __init__(self, ns, action_spec):
        self.name = name

    def enter(self):
        rospy.loginfo("Entering state '" + "'.")

    def run(self):
        raise NotImplementedError()

    def next(self):
        raise NotImplementedError()


class Idle(State):
    def __init__(self):
        super(Idle, self).__init__('idle')

    def run(self):



class CupAcceptorClient(actionlib.SimpleActionClient):

    ns = 'cup_acceptor'

    def __init__(self):
        super(CupAcceptorClient, self).__init__(self.ns, AcceptCupAction)
        self.wait_for_server()
        self.send_goal(AcceptCupGoal(), self.done_cb, self.active_cb, self.feedback_cb)

    def done_cb(self, goal_status, result):
        rospy.loginfo("Cup acceptor finished with status: " + goal_status)
        rospy.loginfo("Result: " + result)




class CupNavigatorClient(actionlib.SimpleActionClient):

    ns = 'cup_navigator'

    def __init__(self):
        super(CupAcceptorClient, self).__init__(self.ns, AcceptCupAction)
        self.wait_for_server()
        self.send_goal(AcceptCupGoal(), self.done_cb, self.active_cb, self.feedback_cb)

    def done_cb(self, goal_status, result):
        rospy.loginfo("Cup acceptor finished its task with status: " + goal_status)
        rospy.loginfo("Result: " + result)


class StateManager:
    def __init__(self, action_name='transport_cup'):
        # rospy.init_node('state_manager')
        self.server = actionlib.SimpleActionServer(action_name, TransportCupAction, self.execute, False)
        self.server.start()

        self.cup_acceptor = actionlib.SimpleActionClient(AcceptCupGoal())

        self.state = CupState.Idle

    def execute(self, goal):
        self.cup_acceptor.wait_for_server()
        self.cup_acceptor.send_goal(AcceptCupGoal(), self.on_step_completed, self.on_step_active, self.on_step_feedback)


        self.server.set_succeeded()



if __name__ == 'main':
    s = StateManager()